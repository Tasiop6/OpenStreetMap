// HW5.cpp
#include <iostream>
#include <iomanip>
#include <string>
#include <iterator>
#include "Graph.hpp"
#include "tinyxml2.h"
#include <limits>

int main() {
    Graph graph;
    std::string choice;

    while (true) {

        // menu lines (commented out for autolab)
        //-i <filepath>  : Import Graph from <filepath>
        //-c             : Compact Graph
        //-p <sid> <eid> : Estimate the shortest path between start <sid> and end <eid>
        //-b <sid>       : Print bfs starting from node with <sid>
        //-d <sid>       : Print dfs starting from node with <sid>
        //-q             : Exit without memory leaks

        // prompt with its own newline
        std::cout << "\nEnter your choice: \n";

        if (!(std::cin >> choice)) break;
        if (choice == "-q") {
            return 0;
        }
        else if (choice == "-i") {
            std::string filepath;
            std::cin >> filepath;
            // discard the rest of the line, up to and including the newline
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            tinyxml2::XMLDocument doc;
            auto err = doc.LoadFile(filepath.c_str());
            if (err != tinyxml2::XML_SUCCESS) {
                if (err == tinyxml2::XML_ERROR_FILE_NOT_FOUND
                    || err == tinyxml2::XML_ERROR_FILE_COULD_NOT_BE_OPENED) {
                    std::cout << "Unable to open file: " << filepath << '\n';
                } else {
                    std::cout << "Invalid format for file: " << filepath << '\n';
                }
            } else {
                graph = Graph(filepath);
                std::cout << "Graph OK\n";
            }
        }
        else if (choice == "-c") {
            graph.compressGraph();
            // blank line before success
            std::cout << '\n';
            std::cout << "Compact OK" << '\n';
        }
        else if (choice == "-p") {
            unsigned long sid, eid;
            std::cin >> sid >> eid;
            auto pathList = graph.findShortestPath(sid, eid);
            double cumulative = 0.0;

            // print edge-by-edge
            for (auto it = pathList.begin(), nxt = std::next(it);
                 nxt != pathList.end();
                 ++it, ++nxt)
            {
                unsigned long u = *it, v = *nxt;
                double d = 0.0;
                for (auto const& e : graph.getVertices()[ graph.getIdToIndex().at(u) ].getEdges()) {
                    if (e.getDestinationId() == v) {
                        d = e.getDistance();
                        break;
                    }
                }
                cumulative += d;
                std::cout << '[' << u << " -> " << v << "] "
                          << std::fixed << std::setprecision(3)
                          << cumulative << '\n';
            }

            // two blanks, then Google Maps URL
            std::cout << '\n' << '\n';
            std::cout << "https://www.google.com/maps/dir/";
            for (auto it = pathList.begin(); it != pathList.end(); ++it) {
                unsigned long id = *it;
                auto const& vert = graph.getVertices()[ graph.getIdToIndex().at(id) ];
                std::cout << vert.getLatitude() << ',' << vert.getLongitude() << '/';
            }
            std::cout << '\n';
        }
        else if (choice == "-b") {
            unsigned long sid;
            std::cin >> sid;
            auto order = graph.breadthFirstSearch(sid);
            for (auto id : order) {
                std::cout << id << '\n';
            }
        }
        else if (choice == "-d") {
            unsigned long sid;
            std::cin >> sid;
            auto order = graph.depthFirstSearch(sid);
            for (auto id : order) {
                std::cout << id << '\n';
            }
        }
    }

    return 0;
}